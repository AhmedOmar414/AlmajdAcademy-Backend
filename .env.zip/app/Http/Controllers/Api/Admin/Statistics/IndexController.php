<?php

namespace App\Http\Controllers\Api\Admin\Statistics;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    public function totalMonthProfit(){

    }
}
